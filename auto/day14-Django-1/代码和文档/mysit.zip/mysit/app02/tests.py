from django.test import TestCase


# Create your tests here.


# def foo(name, age, height):
#     print(f"姓名：{name}，年龄：{age}，身高：{height}cm")
#
#
# foo("alex",180,23)


# def foo(name, age, height):
#     print(f"姓名：{name}，年龄：{age}，身高：{height}cm")
#
#
# foo("yuan",height=180, age=23)
